var test= new Array();
test[0]=new Array('test', 'test2');
test[1]=new Array('test3', 'test4');