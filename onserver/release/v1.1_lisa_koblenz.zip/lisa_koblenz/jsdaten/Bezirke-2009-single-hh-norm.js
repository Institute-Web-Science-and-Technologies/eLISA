var Bezirke2009singlehhnorm = new Array();

Bezirke2009singlehhnorm[0] = new Array("BERICHTSMONAT","NUMMER","BEZIRK","unter_30_dt_m�nnlich","unter_30_dt_weiblich","30_bis_60_dt_m�nnlich","30_bis_60_dt_weiblich","�ber_60_dt_m�nnlich","�ber_60_dt_weiblich","unter_30_ausl_m�nnlich","unter_30_ausl_weiblich","30_bis_60_ausl_m�nnlich","30_bis_60_ausl_weiblich","�ber_60_ausl_m�nnlich","�ber_60_ausl_weiblich","ohne_vollst_Angaben");
Bezirke2009singlehhnorm[1] = new Array(200912,1,"Altstadt-Lehel",0.46,	0.54,	0.98,	0.89,	1.00,	0.67,	0.61,	0.63,	0.93,	1.00,	0.52,	0.97,	0.62);
Bezirke2009singlehhnorm[2] = new Array(200912,2,"Ludwisvorstadt-Isarvorstadt",0.61,	0.63,	1.00,	0.92,	0.19,	0.00,	0.90,	0.76,	1.00,	0.98,	0.60,	0.70,	0.43);
Bezirke2009singlehhnorm[3] = new Array(200912,3,"Maxvorstadt",1.00,	1.00,	0.81,	1.00,	0.42,	0.29,	1.00,	1.00,	0.81,	0.74,	0.35,	0.56,	0.00);
Bezirke2009singlehhnorm[4] = new Array(200912,4,"Schwabing-West", 0.54,	0.64,	0.57,	0.85,	0.54,	0.79,	0.60,	0.70,	0.64,	0.68,	0.24,	0.46,	0.16);
Bezirke2009singlehhnorm[5] = new Array(200912,5,"Au-Haidhausen",0.41,	0.50,	0.73,	0.92,	0.38,	0.36,	0.47,	0.50,	0.66,	0.67,	0.33,	0.71,	0.23);
Bezirke2009singlehhnorm[6] = new Array(200912,6,"Sendling",0.48,	0.55,	0.64,	0.72,	0.33,	0.28,	0.48,	0.40,	0.57,	0.60,	0.37,	0.64,	0.11);
Bezirke2009singlehhnorm[7] = new Array(200912,7,"Sendling-Westpark",0.40,	0.45,	0.39,	0.47,	0.44,	0.70,	0.44,	0.38,	0.36,	0.49,	0.24,	0.65,	0.56);
Bezirke2009singlehhnorm[8] = new Array(200912,8,"Schwanthalerh�he",0.55,	0.48,	0.61,	0.55,	0.17,	0.02,	0.69,	0.57,	0.96,	0.81,	1.00,	1.00,	0.57);
Bezirke2009singlehhnorm[9] = new Array(200912,9,"Neuhausen-Nymphenburg",0.37,	0.46,	0.50,	0.81,	0.36,	0.64,	0.38,	0.37,	0.36,	0.51,	0.22,	0.41,	0.31);
Bezirke2009singlehhnorm[10] = new Array(200912,10,"Moosach",0.20,	0.21,	0.26,	0.28,	0.31,	0.45,	0.31,	0.23,	0.33,	0.42,	0.28,	0.50,	0.24);
Bezirke2009singlehhnorm[11] = new Array(200912,11,"Milbertshofen",0.32,	0.24,	0.26,	0.15,	0.25,	0.23,	0.67,	0.42,	0.62,	0.60,	0.34,	0.71,	0.85);
Bezirke2009singlehhnorm[12] = new Array(200912,12,"Schwabing",0.52,	0.42,	0.45,	0.51,	0.38,	0.46,	0.54,	0.55,	0.42,	0.47,	0.12,	0.30,	0.33);
Bezirke2009singlehhnorm[13] = new Array(200912,13,"Bogenhausen",0.13,	0.20,	0.29,	0.50,	0.48,	0.78,	0.17,	0.29,	0.26,	0.40,	0.17,	0.50,	0.11);
Bezirke2009singlehhnorm[14] = new Array(200912,14,"Berg am Laim",0.24,	0.32,	0.41,	0.42,	0.41,	0.53,	0.42,	0.39,	0.46,	0.57,	0.24,	0.55,	0.38);
Bezirke2009singlehhnorm[15] = new Array(200912,15,"Trudering-Riem",0.00,	0.07,	0.12,	0.18,	0.00,	0.08,	0.08,	0.06,	0.13,	0.10,	0.00,	0.00,	0.30);
Bezirke2009singlehhnorm[16] = new Array(200912,16,"Ramersdorf-Perlach",0.04,	0.08,	0.12,	0.18,	0.27,	0.43,	0.27,	0.21,	0.25,	0.37,	0.22,	0.69,	0.61);
Bezirke2009singlehhnorm[17] = new Array(200912,17,"Obergiesing-Fasangarten",0.45,	0.48,	0.47,	0.52,	0.29,	0.42,	0.66,	0.48,	0.66,	0.64,	0.27,	0.73,	0.24);
Bezirke2009singlehhnorm[18] = new Array(200912,18,"Untergiesing-Harlaching",0.34,	0.42,	0.56,	0.77,	0.66,	1.00,	0.38,	0.33,	0.42,	0.59,	0.24,	0.52,	0.16);
Bezirke2009singlehhnorm[19] = new Array(200912,19,"Thalkirchen-Obersendling",0.16,	0.21,	0.30,	0.41,	0.51,	0.89,	0.22,	0.25,	0.19,	0.32,	0.18,	0.42,	0.02);
Bezirke2009singlehhnorm[20] = new Array(200912,20,"Hadern",0.06,	0.14,	0.00,	0.18,	0.29,	0.60,	0.15,	0.17,	0.05,	0.21,	0.07,	0.39,	0.02);
Bezirke2009singlehhnorm[21] = new Array(200912,21,"Pasing-Obermenzing",0.12,	0.17,	0.21,	0.34,	0.43,	0.68,	0.18,	0.12,	0.13,	0.21,	0.18,	0.21,	0.13);
Bezirke2009singlehhnorm[22] = new Array(200912,22,"Aubing-Lochhausen",0.00,	0.03,	0.01,	0.00,	0.27,	0.40,	0.00,	0.04,	0.00,	0.00,	0.05,	0.05,	0.01);
Bezirke2009singlehhnorm[23] = new Array(200912,23,"Allach-Untermenzing",0.00,	0.04,	0.08,	0.11,	0.15,	0.24,	0.00,	0.00,	0.06,	0.06,	0.12,	0.03,	0.27);
Bezirke2009singlehhnorm[24] = new Array(200912,24,"Feldmoching-Hasenbergl",0.04,	0.00,	0.04,	0.01,	0.05,	0.09,	0.27,	0.11,	0.24,	0.15,	0.19,	0.31,	1.00);
Bezirke2009singlehhnorm[25] = new Array(200912,25,"Laim",0.46,	0.52,	0.48,	0.62,	0.58,	0.84,	0.51,	0.45,	0.40,	0.51,	0.26,	0.61,	0.35);
Bezirke2009singlehhnorm[26] = new Array(200912,99,"nicht zuzuordnen",0,0,0,0,0,0,0,0,0,0,0,0,0);


























